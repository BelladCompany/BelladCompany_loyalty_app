const RedemptionService = require('../services/redemption.service');
const RedemptionEligibilityService = require('../services/redemption_eligibility.service');

class RedemptionController {
  /**
   * Request OTP for customer redemption (6-digit, 5-min expiry, rate limited 5/hr)
   */
  static async requestOtp(req, res, next) {
    try {
      const { phone, customer_id } = req.body;
      const tenantId = req.tenantId;

      const result = await RedemptionService.requestOtp({
        phone,
        customer_id,
        tenant_id: tenantId,
      });

      res.status(200).json({
        status: 'success',
        message: `OTP sent successfully to ${result.phone_number}. Valid for 5 minutes.`,
        data: result,
      });
    } catch (error) {
      next(error);
    }
  }

  /**
   * Cashier submits phone, OTP, points, and vehicle_id to redeem.
   * vehicle_id is now required — each vehicle has its own independent redemption clock.
   */
  static async redeemPoints(req, res, next) {
    try {
      const { phone, otp, points, branch_id, vehicle_id } = req.body;
      const tenantId = req.tenantId;
      const createdBy = req.user?.id || null;

      const result = await RedemptionService.redeemPoints({
        phone,
        otp,
        points,
        branch_id,
        vehicle_id: vehicle_id ? parseInt(vehicle_id, 10) : null,
        created_by: createdBy,
        tenant_id: tenantId,
      });

      res.status(200).json({
        status: 'success',
        message: `Redemption successful. Discount of ₹${result.discount.rupees} applied.`,
        data: {
          redemption_code: result.redemption.redemption_code,
          discount_amount_rupees: result.discount.rupees,
          discount_amount_paise: result.discount.paise,
          points_redeemed: result.balance.points_redeemed,
          remaining_balance: result.balance.remaining_balance,
          redemption_details: result.redemption,
          eligibility: result.eligibility,
        },
      });
    } catch (error) {
      next(error);
    }
  }

  /**
   * Fetch redemption record by unique code
   */
  static async getRedemption(req, res, next) {
    try {
      const { code } = req.params;
      const tenantId = req.tenantId;

      const redemption = await RedemptionService.getRedemptionByCode(code, tenantId);

      if (!redemption) {
        return res.status(404).json({
          status: 'fail',
          error: `Redemption record not found for code: '${code}'`,
        });
      }

      res.status(200).json({
        status: 'success',
        data: redemption,
      });
    } catch (error) {
      next(error);
    }
  }

  /**
   * GET /api/redemptions/vehicle/:vehicle_id/status
   *
   * Returns the redemption status (locked/eligible/expired) for a vehicle,
   * including the eligible_at / expires_at dates and the redeemable points balance.
   * Used by the cashier UI to show the status banner before the OTP step.
   */
  static async getVehicleRedemptionStatus(req, res, next) {
    try {
      const vehicleId = parseInt(req.params.vehicle_id, 10);
      const tenantId = req.tenantId;

      if (!vehicleId || isNaN(vehicleId)) {
        return res.status(400).json({ status: 'fail', error: 'Invalid vehicle_id.' });
      }

      const statusData = await RedemptionEligibilityService.getVehicleRedemptionStatus(vehicleId, tenantId);

      res.status(200).json({
        status: 'success',
        data: statusData,
      });
    } catch (error) {
      next(error);
    }
  }
}

module.exports = RedemptionController;
