const bcrypt = require('bcryptjs');
const { pool } = require('../config/db');
const env = require('../config/env');

async function seed() {
  console.log('🌱 Seeding initial database records...');
  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    const tenantId = env.defaultTenantId;

    // 1. Seed Brands
    // DB NOTE: brands.code no longer exists in the live schema, and the old
    // UNIQUE(tenant_id, code) constraint that ON CONFLICT relied on is gone with it.
    // We do a manual find-or-create against (tenant_id, brand_name) instead.
    let brandRow = (await client.query(
      `SELECT brand_id AS id, brand_name AS name FROM brands WHERE tenant_id = $1 AND brand_name = $2;`,
      [tenantId, 'Maruti Suzuki']
    )).rows[0];
    if (!brandRow) {
      brandRow = (await client.query(
        `INSERT INTO brands (brand_name, tenant_id)
         VALUES ($1, $2)
         RETURNING brand_id AS id, brand_name AS name;`,
        ['Maruti Suzuki', tenantId]
      )).rows[0];
    }
    const brandId = brandRow.id;
    console.log(`- Seeded brand: ${brandRow.name} (ID: ${brandId})`);

    // 2. Seed Branches
    // DB NOTE: branches.code no longer exists either; same find-or-create approach,
    // keyed on (tenant_id, branch_name).
    let branchRow = (await client.query(
      `SELECT branch_id AS id, branch_name AS name FROM branches WHERE tenant_id = $1 AND branch_name = $2;`,
      [tenantId, 'Central Showroom - Bangalore']
    )).rows[0];
    if (!branchRow) {
      branchRow = (await client.query(
        `INSERT INTO branches (branch_name, branch_city, tenant_id)
         VALUES ($1, $2, $3)
         RETURNING branch_id AS id, branch_name AS name;`,
        ['Central Showroom - Bangalore', 'Bangalore', tenantId]
      )).rows[0];
    }
    const branchId = branchRow.id;
    console.log(`- Seeded branch: ${branchRow.name} (ID: ${branchId})`);

    // 3. Seed Users (admin and cashier)
    const adminPasswordHash = await bcrypt.hash('Admin@123', 10);
    const cashierPasswordHash = await bcrypt.hash('Cashier@123', 10);

    const adminUserRes = await client.query(
      `INSERT INTO users (username, password_hash, role, branch_id, tenant_id)
       VALUES ($1, $2, $3, $4, $5)
       ON CONFLICT (tenant_id, username) DO UPDATE SET password_hash = EXCLUDED.password_hash
       RETURNING user_id, username;`,
      ['admin', adminPasswordHash, 'admin', branchId, tenantId]
    );
    const adminUserId = adminUserRes.rows[0].user_id;
    console.log('- Seeded user: admin (role: admin, password: Admin@123)');

    await client.query(
      `INSERT INTO users (username, password_hash, role, branch_id, tenant_id)
       VALUES ($1, $2, $3, $4, $5)
       ON CONFLICT (tenant_id, username) DO UPDATE SET password_hash = EXCLUDED.password_hash;`,
      ['cashier', cashierPasswordHash, 'cashier', branchId, tenantId]
    );
    console.log('- Seeded user: cashier (role: cashier, password: Cashier@123)');

    // 4. Seed Referral Approver for Admin
    const approverRes = await client.query(
      `INSERT INTO referral_approvers (user_id, name, is_active, tenant_id)
       VALUES ($1, $2, $3, $4)
       ON CONFLICT (tenant_id, user_id) DO UPDATE SET is_active = TRUE
       RETURNING id, name;`,
      [adminUserId, 'Admin Approver', true, tenantId]
    );
    console.log(`- Seeded referral approver: ${approverRes.rows[0].name} (ID: ${approverRes.rows[0].id})`);

    // 5. Seed Tier Rules
    const tiers = [
      { name: 'Silver', minPoints: 0, multiplier: 100 },
      { name: 'Gold', minPoints: 5000, multiplier: 125 },
      { name: 'Platinum', minPoints: 15000, multiplier: 150 },
    ];

    for (const tier of tiers) {
      await client.query(
        `INSERT INTO tier_rules (tier_name, min_points, multiplier, tenant_id)
         VALUES ($1, $2, $3, $4)
         ON CONFLICT (tenant_id, tier_name) DO UPDATE 
         SET min_points = EXCLUDED.min_points, multiplier = EXCLUDED.multiplier;`,
        [tier.name, tier.minPoints, tier.multiplier, tenantId]
      );
    }
    console.log('- Seeded default tier rules (Silver, Gold, Platinum)');

    await client.query('COMMIT');
    console.log('✅ Seeding completed successfully!');
  } catch (error) {
    await client.query('ROLLBACK');
    console.error('❌ Seeding failed:', error);
    process.exit(1);
  } finally {
    client.release();
    await pool.end();
  }
}

if (require.main === module) {
  seed();
}

module.exports = seed;
