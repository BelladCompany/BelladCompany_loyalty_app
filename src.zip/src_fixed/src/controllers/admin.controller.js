const MergeService = require('../services/merge.service');
const RealBooksService = require('../services/realbooks/realbooks.service');

class AdminController {
  /**
   * Get duplicate candidate customer pairs queue
   */
  static async getDuplicateQueue(req, res, next) {
    try {
      const tenantId = req.tenantId;
      const candidates = await MergeService.detectDuplicates(tenantId);

      res.status(200).json({
        status: 'success',
        count: candidates.length,
        data: candidates,
      });
    } catch (error) {
      next(error);
    }
  }

  /**
   * Approve and execute customer merge
   */
  static async approveMerge(req, res, next) {
    try {
      const { surviving_customer_id, merged_customer_id, reason } = req.body;
      const tenantId = req.tenantId;
      const adminUserId = req.user.id;

      const result = await MergeService.executeMerge({
        surviving_customer_id,
        merged_customer_id,
        reason,
        admin_user_id: adminUserId,
        tenant_id: tenantId,
      });

      res.status(200).json({
        status: 'success',
        message: `Customer ${merged_customer_id} successfully merged into ${surviving_customer_id}.`,
        data: result,
      });
    } catch (error) {
      next(error);
    }
  }

  /**
   * List customer merge audit logs
   */
  static async getMergeLogs(req, res, next) {
    try {
      const tenantId = req.tenantId;
      const limit = parseInt(req.query.limit || '50', 10);
      const offset = parseInt(req.query.offset || '0', 10);

      const logs = await MergeService.listMergeLogs(tenantId, limit, offset);

      res.status(200).json({
        status: 'success',
        results: logs.length,
        data: logs,
      });
    } catch (error) {
      next(error);
    }
  }

  /**
   * View RealBooks sync failures
   */
  static async getRealBooksSyncFailures(req, res, next) {
    try {
      const tenantId = req.tenantId;
      const limit = parseInt(req.query.limit || '50', 10);
      const offset = parseInt(req.query.offset || '0', 10);

      const failures = await RealBooksService.getSyncFailures(tenantId, limit, offset);

      res.status(200).json({
        status: 'success',
        count: failures.length,
        data: failures,
      });
    } catch (error) {
      next(error);
    }
  }

  /**
   * Manually trigger retry for a failed RealBooks sync log
   */
  static async retryRealBooksSync(req, res, next) {
    try {
      const { id } = req.params;
      const tenantId = req.tenantId;

      const result = await RealBooksService.manuallyRetrySync(id, tenantId);

      res.status(200).json({
        status: 'success',
        message: `RealBooks sync log '${id}' retry initiated.`,
        data: result,
      });
    } catch (error) {
      next(error);
    }
  }
}

module.exports = AdminController;
