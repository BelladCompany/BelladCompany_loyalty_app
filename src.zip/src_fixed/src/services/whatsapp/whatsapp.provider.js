/**
 * Pluggable WhatsApp Provider Interface and Mock Implementation
 */

class BaseWhatsAppProvider {
  /**
   * Sends a WhatsApp message to a phone number
   * @param {Object} options
   * @param {string} options.toPhone Target phone number (e.g. +919876543210)
   * @param {string} options.message Formatted WhatsApp message body
   * @returns {Promise<{ success: boolean, messageId: string, provider: string }>}
   */
  async sendMessage({ toPhone, message }) {
    throw new Error('BaseWhatsAppProvider.sendMessage must be implemented by concrete provider');
  }
}

class MockWhatsAppProvider extends BaseWhatsAppProvider {
  constructor() {
    super();
    this.name = 'MockWhatsAppProvider';
    this.sentMessages = [];
  }

  async sendMessage({ toPhone, message }) {
    const messageId = `WA-MOCK-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    const logEntry = {
      messageId,
      toPhone,
      message,
      provider: this.name,
      status: 'delivered',
      timestamp: new Date().toISOString(),
    };

    this.sentMessages.push(logEntry);
    console.log(`\n📲 [WhatsApp Notification Sent via ${this.name}]`);
    console.log(`Recipient: ${toPhone}`);
    console.log(`Message ID: ${messageId}`);
    console.log(`Body:\n${message}\n`);

    return {
      success: true,
      messageId,
      provider: this.name,
      status: 'delivered',
    };
  }
}

let providerInstance = null;

function getWhatsAppProvider() {
  if (!providerInstance) {
    // Allows switching to external providers (e.g. Twilio / Meta Cloud API) via env configuration
    providerInstance = new MockWhatsAppProvider();
  }
  return providerInstance;
}

module.exports = {
  BaseWhatsAppProvider,
  MockWhatsAppProvider,
  getWhatsAppProvider,
};
