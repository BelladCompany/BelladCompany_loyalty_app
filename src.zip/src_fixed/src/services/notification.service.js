const { pool } = require('../config/db');
const { getWhatsAppProvider } = require('./whatsapp/whatsapp.provider');
const AuditLogService = require('./audit.service');

class NotificationService {
  /**
   * Formats message string using the EXACT template required by specification.
   * Do not alter or reword this format.
   */
  static formatMessage({ points, transactionType, totalPoints, value }) {
    return (
      `🎉 Congratulations!\n` +
      `You have earned ${points} loyalty points from your recent ${transactionType} transaction.\n` +
      `⭐ Points earned: ${points}\n` +
      `💰 Total available points: ${totalPoints}\n` +
      `💵 Loyalty value: ₹${value}\n` +
      `Thank you for choosing us!`
    );
  }

  /**
   * Processes points-earned notification:
   * 1. Resolves customer's primary phone number
   * 2. Computes LIVE points balance from points_ledger (never cached) at send time
   * 3. Formats exact template
   * 4. Dispatches via pluggable WhatsApp provider
   * 5. Logs delivery status
   */
  static async sendPointsEarnedNotification({ customer_id, points, transaction_type, tenant_id }) {
    try {
      // 1. Fetch customer's primary phone number
      const phoneRes = await pool.query(
        `SELECT phone_number
         FROM customer_phones
         WHERE customer_id = $1 AND tenant_id = $2
         ORDER BY is_verified DESC, phone_id ASC
         LIMIT 1;`,
        [customer_id, tenant_id]
      );

      if (phoneRes.rows.length === 0) {
        console.warn(`⚠️ [Notification] No phone number found for customer '${customer_id}'. Skipping WhatsApp send.`);
        return { success: false, reason: 'No phone number registered' };
      }

      const toPhone = phoneRes.rows[0].phone_number;

      // 2. Compute LIVE total available points from points_ledger at send time (never cached)
      const balanceRes = await pool.query(
        `SELECT COALESCE(SUM(points), 0) AS total_points
         FROM points_ledger
         WHERE customer_id = $1 AND tenant_id = $2;`,
        [customer_id, tenant_id]
      );

      const totalPoints = parseInt(balanceRes.rows[0].total_points, 10);

      // 3. Compute loyalty value in Rupees (4 points = 1 rupee, integer precision)
      const valueRupees = Math.floor(totalPoints / 4);

      // Normalize transaction type for display (e.g. 'earn_referral' -> 'referral')
      const displayTxType = transaction_type === 'earn_referral' ? 'referral' : transaction_type;

      // 4. Format message using EXACT specified template
      const messageBody = this.formatMessage({
        points,
        transactionType: displayTxType,
        totalPoints,
        value: valueRupees,
      });

      // 5. Send via pluggable WhatsApp provider
      const provider = getWhatsAppProvider();
      const result = await provider.sendMessage({
        toPhone,
        message: messageBody,
      });

      // 6. Log delivery status to audit_log (using the audit_log schema columns)
      await AuditLogService.logEvent({
        action: 'whatsapp_notification_sent',
        entity_type: 'customer',
        entity_id: customer_id,
        actor_user_id: null,
        metadata: {
          to_phone: toPhone,
          points_earned: points,
          transaction_type: displayTxType,
          total_points_live: totalPoints,
          loyalty_value_rupees: valueRupees,
          provider_status: result,
        },
        tenant_id,
      }).catch((err) => console.error('Failed to log notification delivery audit:', err.message));

      return {
        success: result.success,
        customer_id,
        to_phone: toPhone,
        total_points_live: totalPoints,
        loyalty_value_rupees: valueRupees,
        message_body: messageBody,
      };
    } catch (error) {
      console.error(`❌ [Notification Error] Failed to send WhatsApp message for customer '${customer_id}':`, error);
      return { success: false, error: error.message };
    }
  }

  /**
   * Enqueues notification asynchronously without blocking main transaction or HTTP response
   */
  static queuePointsEarnedNotification(data) {
    setImmediate(() => {
      this.sendPointsEarnedNotification(data).catch((err) =>
        console.error('Asynchronous notification worker error:', err)
      );
    });
  }
}

module.exports = NotificationService;
