const { pool } = require('../config/db');
const NotificationService = require('./notification.service');
const AuditLogService = require('./audit.service');

class PointsService {
  /**
   * Calculates points using exact integer arithmetic and configurable rates from point_rules table
   */
  static async calculatePoints(type, amount, tenantId, client = pool) {
    const ruleRes = await client.query(
      `SELECT multiplier_numerator, multiplier_denominator
       FROM point_rules
       WHERE rule_type = $1 AND tenant_id = $2;`,
      [type, tenantId]
    );

    let numerator = type === 'service' ? 4n : 1n;
    let denominator = 100n;

    if (ruleRes.rows.length > 0) {
      numerator = BigInt(ruleRes.rows[0].multiplier_numerator);
      denominator = BigInt(ruleRes.rows[0].multiplier_denominator);
    }

    if (denominator === 0n) {
      throw new Error('Invalid point rule: denominator cannot be zero');
    }

    const amt = BigInt(amount);
    // Exact integer division (never floating point)
    const points = (amt * numerator) / denominator;

    return Number(points);
  }

  /**
   * Records a points-earning transaction, writes immutable ledger row, updates tier snapshot,
   * logs audit trail, and asynchronously triggers non-blocking WhatsApp notification.
   */
  static async recordEarning({
    customer_id,
    branch_id,
    amount,
    type,
    reference_id,
    description,
    created_by,
    tenant_id,
  }) {
    const client = await pool.connect();
    try {
      await client.query('BEGIN');

      // 1. Verify customer exists and get before-balance snapshot
      const custRes = await client.query(
        `SELECT c.customer_id, c.customer_name AS name,
                COALESCE(cts.current_balance, 0) AS current_balance,
                COALESCE(cts.lifetime_points, 0) AS lifetime_points
         FROM customers c
         LEFT JOIN customer_tier_snapshot cts ON c.customer_id = cts.customer_id AND c.tenant_id = cts.tenant_id
         WHERE c.customer_id = $1 AND c.tenant_id = $2;`,
        [customer_id, tenant_id]
      );
      if (custRes.rows.length === 0) {
        throw { statusCode: 404, message: `Customer '${customer_id}' not found in tenant '${tenant_id}'` };
      }

      const balanceBefore = parseInt(custRes.rows[0].current_balance, 10);
      const lifetimeBefore = parseInt(custRes.rows[0].lifetime_points, 10);

      // 2. Verify branch exists
      const branchRes = await client.query(
        `SELECT branch_id AS id, branch_name AS name FROM branches WHERE branch_id = $1 AND tenant_id = $2;`,
        [branch_id, tenant_id]
      );
      if (branchRes.rows.length === 0) {
        throw { statusCode: 404, message: `Branch ID '${branch_id}' not found in tenant '${tenant_id}'` };
      }

      // 3. Calculate points using configurable point_rules with exact integer math
      const earnedPoints = await this.calculatePoints(type, amount, tenant_id, client);

      // 4. Insert immutable record into points_ledger
      const ledgerRes = await client.query(
        `INSERT INTO points_ledger (
          customer_id, branch_id, transaction_type, points, amount_paise,
          reason, reference_id, created_by, tenant_id
        )
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
        RETURNING id, customer_id, branch_id, transaction_type, points,
                  amount_paise, reason, reference_id, created_by, tenant_id, created_at;`,
        [
          customer_id,
          branch_id,
          type,
          earnedPoints,
          amount,
          description || `${type.toUpperCase()} transaction earning`,
          reference_id || null,
          created_by || null,
          tenant_id,
        ]
      );

      const ledgerEntry = ledgerRes.rows[0];

      // 5. Calculate lifetime points and current balance from ledger
      const aggRes = await client.query(
        `SELECT 
           COALESCE(SUM(CASE WHEN points > 0 THEN points ELSE 0 END), 0) AS lifetime_points,
           COALESCE(SUM(points), 0) AS current_balance
         FROM points_ledger
         WHERE customer_id = $1 AND tenant_id = $2;`,
        [customer_id, tenant_id]
      );

      const lifetimePoints = parseInt(aggRes.rows[0].lifetime_points, 10);
      const currentBalance = parseInt(aggRes.rows[0].current_balance, 10);

      // 6. Recalculate customer tier from tier_rules (lifetime points threshold)
      const tierRes = await client.query(
        `SELECT id, tier_name, min_points, multiplier
         FROM tier_rules
         WHERE tenant_id = $1 AND min_points <= $2
         ORDER BY min_points DESC, id DESC
         LIMIT 1;`,
        [tenant_id, lifetimePoints]
      );

      const tier = tierRes.rows.length > 0
        ? tierRes.rows[0]
        : { id: null, tier_name: 'Standard' };

      // 7. Store / upsert customer tier snapshot
      const snapshotRes = await client.query(
        `INSERT INTO customer_tier_snapshot (
           customer_id, tier_id, tier_name, lifetime_points, current_balance, tenant_id, updated_at
         )
         VALUES ($1, $2, $3, $4, $5, $6, NOW())
         ON CONFLICT (customer_id) DO UPDATE
         SET tier_id = EXCLUDED.tier_id,
             tier_name = EXCLUDED.tier_name,
             lifetime_points = EXCLUDED.lifetime_points,
             current_balance = EXCLUDED.current_balance,
             updated_at = NOW()
         RETURNING customer_id, tier_id, tier_name, lifetime_points, current_balance, updated_at;`,
        [customer_id, tier.id, tier.tier_name, lifetimePoints, currentBalance, tenant_id]
      );

      const tierSnapshot = snapshotRes.rows[0];

      // 8. Log system audit event for points earning
      const actionName = type === 'sale' ? 'points_earn_sale' : (type === 'service' ? 'points_earn_service' : 'points_adjustment');
      await AuditLogService.logEvent({
        action: actionName,
        entity_type: 'customer',
        entity_id: customer_id,
        actor_user_id: created_by || null,
        before_values: { current_balance: balanceBefore, lifetime_points: lifetimeBefore },
        after_values: { current_balance: currentBalance, lifetime_points: lifetimePoints },
        metadata: {
          earned_points: earnedPoints,
          transaction_type: type,
          amount_paise: amount,
          reference_id: reference_id || null,
          branch_id,
          description: description || null,
        },
        tenant_id,
        client,
      });

      await client.query('COMMIT');

      // 8. Queue non-blocking WhatsApp notification (does not block HTTP response)
      NotificationService.queuePointsEarnedNotification({
        customer_id,
        points: earnedPoints,
        transaction_type: type,
        tenant_id,
      });

      return {
        ledger_entry: ledgerEntry,
        tier_snapshot: tierSnapshot,
      };
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  }

  /**
   * Fetches full customer ledger history and current tier snapshot
   */
  static async getCustomerLedgerAndTier(customerId, tenantId, limit = 20, offset = 0) {
    // 1. Verify customer exists
    const custRes = await pool.query(
      `SELECT customer_id, customer_name AS name, NULL::text AS email FROM customers WHERE customer_id = $1 AND tenant_id = $2;`,
      [customerId, tenantId]
    );

    if (custRes.rows.length === 0) {
      return null;
    }

    const customer = custRes.rows[0];

    // 2. Fetch current tier snapshot
    let snapshotRes = await pool.query(
      `SELECT cts.customer_id, cts.tier_id, cts.tier_name, cts.lifetime_points, cts.current_balance, cts.updated_at,
              tr.multiplier AS tier_multiplier
       FROM customer_tier_snapshot cts
       LEFT JOIN tier_rules tr ON cts.tier_id = tr.id
       WHERE cts.customer_id = $1 AND cts.tenant_id = $2;`,
      [customerId, tenantId]
    );

    let tierSnapshot = snapshotRes.rows[0];

    // If no snapshot exists yet, construct default baseline
    if (!tierSnapshot) {
      tierSnapshot = {
        customer_id: customerId,
        tier_id: null,
        tier_name: 'Silver',
        lifetime_points: 0,
        current_balance: 0,
        tier_multiplier: 100,
        updated_at: new Date().toISOString(),
      };
    }

    // 3. Total ledger records count
    const countRes = await pool.query(
      `SELECT COUNT(*) AS total FROM points_ledger WHERE customer_id = $1 AND tenant_id = $2;`,
      [customerId, tenantId]
    );
    const totalCount = parseInt(countRes.rows[0].total, 10);

    // 4. Fetch paginated ledger entries
    const entriesRes = await pool.query(
      `SELECT pl.id, pl.customer_id, pl.branch_id, b.branch_name AS branch_name,
              pl.transaction_type, pl.points, pl.amount_paise, pl.reason,
              pl.reference_id, pl.created_by, u.username AS created_by_username,
              pl.created_at
       FROM points_ledger pl
       LEFT JOIN branches b ON pl.branch_id = b.branch_id
       LEFT JOIN users u ON pl.created_by = u.user_id
       WHERE pl.customer_id = $1 AND pl.tenant_id = $2
       ORDER BY pl.created_at DESC, pl.id DESC
       LIMIT $3 OFFSET $4;`,
      [customerId, tenantId, limit, offset]
    );

    return {
      customer: {
        customer_id: customer.customer_id,
        name: customer.name,
        email: customer.email,
      },
      current_tier: {
        tier_id: tierSnapshot.tier_id,
        tier_name: tierSnapshot.tier_name,
        lifetime_points: parseInt(tierSnapshot.lifetime_points, 10),
        current_balance: parseInt(tierSnapshot.current_balance, 10),
        tier_multiplier: tierSnapshot.tier_multiplier || 100,
        last_updated: tierSnapshot.updated_at,
      },
      pagination: {
        total: totalCount,
        limit,
        offset,
      },
      ledger_entries: entriesRes.rows,
    };
  }
}

module.exports = PointsService;
