const { pool } = require('../../config/db');
const realbooksClient = require('./realbooks.client');

class RealBooksService {
  /**
   * Queues a new redemption record for RealBooks API sync
   */
  static async queueRedemptionSync({ redemption, tenant_id, simulate_fail = false }) {
    const payload = {
      redemption_code: redemption.redemption_code,
      customer_id: redemption.customer_id,
      discount_amount_rupees: redemption.discount_amount_rupees,
      discount_amount_paise: redemption.discount_amount_paise,
      points_redeemed: redemption.points_redeemed,
      branch_id: redemption.branch_id,
      timestamp: redemption.created_at || new Date().toISOString(),
      ...(simulate_fail ? { simulate_fail: true } : {}),
    };

    const logRes = await pool.query(
      `INSERT INTO realbooks_sync_log (
         redemption_id, redemption_code, status, retry_count, max_retries,
         request_payload, tenant_id
       )
       VALUES ($1, $2, 'pending', 0, 5, $3, $4)
       RETURNING id, redemption_id, redemption_code, status, retry_count, tenant_id;`,
      [redemption.id, redemption.redemption_code, JSON.stringify(payload), tenant_id]
    );

    const syncLog = logRes.rows[0];

    // Asynchronously trigger initial sync attempt without blocking caller
    setImmediate(() => {
      this.attemptSyncLog(syncLog.id).catch((err) =>
        console.error(`Error in async RealBooks sync attempt for log ${syncLog.id}:`, err.message)
      );
    });

    return syncLog;
  }

  /**
   * Attempts to push a sync log to RealBooks API with exponential backoff on failure
   */
  static async attemptSyncLog(syncLogId) {
    const logRes = await pool.query(
      `SELECT id, redemption_id, redemption_code, status, retry_count, max_retries,
              request_payload, tenant_id
       FROM realbooks_sync_log
       WHERE id = $1;`,
      [syncLogId]
    );

    if (logRes.rows.length === 0) return null;
    const log = logRes.rows[0];

    try {
      const response = await realbooksClient.pushRedemption(log.request_payload);

      // Sync Success
      const updatedRes = await pool.query(
        `UPDATE realbooks_sync_log
         SET status = 'synced',
             response_payload = $1,
             next_retry_at = NULL,
             last_error = NULL,
             updated_at = NOW()
         WHERE id = $2
         RETURNING id, redemption_code, status, retry_count, response_payload;`,
        [JSON.stringify(response), syncLogId]
      );

      console.log(`✅ [RealBooks Sync Success] Log ID: ${syncLogId}, Code: ${log.redemption_code}`);
      return updatedRes.rows[0];
    } catch (error) {
      // Sync Failure: Compute exponential backoff retry schedule
      const nextRetryCount = log.retry_count + 1;
      // Formula: delayInSeconds = min(3600, 30 * 2^retryCount)
      const delaySeconds = Math.min(3600, 30 * Math.pow(2, nextRetryCount));

      const updatedRes = await pool.query(
        `UPDATE realbooks_sync_log
         SET status = 'failed',
             retry_count = $1,
             last_error = $2,
             next_retry_at = NOW() + ($3 || ' seconds')::INTERVAL,
             updated_at = NOW()
         WHERE id = $4
         RETURNING id, redemption_code, status, retry_count, next_retry_at, last_error;`,
        [nextRetryCount, error.message, delaySeconds.toString(), syncLogId]
      );

      console.warn(`⚠️ [RealBooks Sync Failed] Log ID: ${syncLogId}, Attempt: ${nextRetryCount}/${log.max_retries}. Next retry in ${delaySeconds}s`);
      return updatedRes.rows[0];
    }
  }

  /**
   * Background retry worker: processes failed sync logs eligible for retry
   */
  static async processPendingRetryQueue() {
    try {
      const pendingLogsRes = await pool.query(
        `SELECT id, redemption_code, retry_count
         FROM realbooks_sync_log
         WHERE status = 'failed'
           AND retry_count < max_retries
           AND (next_retry_at IS NULL OR next_retry_at <= NOW())
         LIMIT 20;`
      );

      if (pendingLogsRes.rows.length === 0) return;

      console.log(`\n🔄 [RealBooks Retry Worker] Retrying ${pendingLogsRes.rows.length} pending failed sync logs...`);

      for (const log of pendingLogsRes.rows) {
        await this.attemptSyncLog(log.id);
      }
    } catch (error) {
      console.error('Error running RealBooks background retry worker:', error.message);
    }
  }

  /**
   * Retrieves RealBooks sync failures for admin inspection
   */
  static async getSyncFailures(tenantId, limit = 50, offset = 0) {
    const res = await pool.query(
      `SELECT rsl.id, rsl.redemption_id, rsl.redemption_code, rsl.status,
              rsl.retry_count, rsl.max_retries, rsl.next_retry_at, rsl.last_error,
              rsl.request_payload, rsl.response_payload, rsl.created_at, rsl.updated_at,
              r.customer_id, r.discount_amount_rupees
       FROM realbooks_sync_log rsl
       JOIN redemptions r ON rsl.redemption_id = r.id AND rsl.tenant_id = r.tenant_id
       WHERE rsl.tenant_id = $1 AND rsl.status = 'failed'
       ORDER BY rsl.updated_at DESC
       LIMIT $2 OFFSET $3;`,
      [tenantId, limit, offset]
    );

    return res.rows;
  }

  /**
   * Admin trigger to manually retry a failed sync log immediately
   */
  static async manuallyRetrySync(syncLogId, tenantId) {
    const logCheck = await pool.query(
      `SELECT id FROM realbooks_sync_log WHERE id = $1 AND tenant_id = $2;`,
      [syncLogId, tenantId]
    );

    if (logCheck.rows.length === 0) {
      throw { statusCode: 404, message: `RealBooks sync log '${syncLogId}' not found.` };
    }

    return this.attemptSyncLog(syncLogId);
  }
}

module.exports = RealBooksService;
